# Prompt bàn giao cho AI tiếp theo (CANVIO)

Bạn là Senior Product Designer kiêm Frontend Engineer của CANVIO (một file `index.html`, miễn phí, không API trả phí). Người dùng viết tiếng Việt, muốn giao diện tinh tế, dễ dùng, nút chính luôn nhìn thấy, ít tốn usage.

## Trước khi làm
1. Đọc `CANVIO_AI_GUIDE.md` (kiến trúc) rồi các mục P131.1, P131.2, P127.1, P127.4 cuối `CANVIO_ROADMAP.md`. Không quét lại toàn bộ `index.html`; dùng `grep -n` có ngữ cảnh.
2. `index.html` dùng đuôi dòng CRLF. Khi sửa bằng script, đọc/ghi nhị phân (`rb`/`wb`) và giữ `\r\n`, nếu không `git diff` sẽ đổi cả file.
3. Quy tắc: chỉ thêm hoặc bọc, không xóa tính năng; mỗi lô là một `<script id="canvio-lotNNN">` kèm bản độc lập `canvio-pNNN-*.js` (test kiểm hai bản khớp).

## Cách kiểm (đã chạy được trong sandbox không có mạng)
- `node tests/p131/run-p131-tests.cjs`, `node tests/p127/run-p127q-tests.cjs`, và các test nguồn trong `.github/workflows/canvio-candidate-runtime.yml`.
- Chrome thật: `python3 tests/p131/run-p131-browser.py` và `run-p131-app-smoke.py`. Cờ cần thiết: `--disable-gpu`, `--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1`, `reduced_motion='reduce'`. `wait_for_function` phải bọc `!!(...)` (Playwright tự gọi nếu kết quả là hàm).
- Cạm bẫy đã gặp: `classList.add/remove` và `setAttribute` cùng giá trị vẫn tạo bản ghi `MutationObserver`; callback ghi lại đúng thuộc tính đang quan sát sẽ lặp vô hạn. Luôn kiểm `contains`/so sánh trước khi ghi.
- `tests/p57` đỏ khi chạy trần từ trước (CI áp override); không phải lỗi mới.

## Việc còn mở, theo thứ tự đề xuất
1. **P131 còn lại:** nối `CANVIOSecurity.sanitizeHtml` vào đường nhập HTML website/Content Factory; giới hạn kích thước/độ sâu khi giải nén ZIP/PPTX/PSD (chống zip bomb); gắn `redact` vào các đường xuất; cân nhắc mặc định khóa Gemini vào bộ nhớ phiên có thông báo.
2. **P127.2/P127.3/P127.5:** AutoCut theo Whisper timestamp, jump cut, zoom nhấn; SFX/nhạc cục bộ, ducking, đo LUFS; mẫu Short/Reel, YouTube dài, Event recap. Mở rộng cổng chất lượng P127.4 với headroom/safe area, tương phản chữ, glow/bloom khi có dữ liệu khung hình.
3. **P142:** kiểm thử trên Chrome thật của người dùng (Windows, GTX 1650, RAM 7 GB) cho các tính năng GPU/AI.
4. Các mục P116–P145 chưa có trạng thái "Đã nghiệm thu" trong `CANVIO_ROADMAP.md`.

## Báo cáo
Sau mỗi lô: cập nhật `CANVIO_ROADMAP.md` (Đã có / Một phần / Chưa, kèm giới hạn trung thực), thêm 1–2 dòng vào `CANVIO_AI_GUIDE.md`, commit nhỏ có thông điệp rõ, đẩy lên `main`. Không khẳng định đã kiểm nếu chưa chạy.

## Cập nhật 2026-11-20 (sau P145 core)
Đã có thêm: P127.3 (LUFS), P127.5 (mẫu), P125.1/P125.3/P125.4-phần giảm dung lượng (web cuộn từ video), P145 core (giấy phép, cue sheet, kiểm font, data merge, JSONL).
Pull trước khi làm: CI bot hay push commit "build: commit verified ..." lên main; dùng `git pull --rebase origin main`.
Việc còn mở theo thứ tự gợi ý: P125.2 editor cuộn; P132 xuất GIF/APNG/WebP động; P136 Image Trace; P137 kiểu đoạn/bảng/luồng chữ; P138 khử ồn + TTS; P145.3 SFX Web Audio; P145.2 shader chuyển cảnh; P134 waveform/vectorscope; P124 Auto Layout/Component; P133 OPFS/proxy; P143 tách mã; P144 Command Palette; P145.4b trình phát nhúng tự phát; P130 (chặn: cần Supabase thật); P142 kiểm Firefox/WebKit/cảm ứng.
Quy tắc nhúng: mỗi lot là `<script id="canvio-lotNNN">` + bản độc lập `canvio-pNNN-*.js`; không viết chuỗi `</script>` thật trong mã (dùng `<\/script>`); index.html dùng CRLF, sửa bằng đọc/ghi nhị phân.



## Cập nhật tiếp tục 2026-11-21 — P134.2 candidate

- P134.2 Auto Reframe bản nhẹ đã có source canvio-p134-reframe.js, Node test tests/p127/run-p134r-tests.cjs (11 assertions), Chromium/ffprobe test tests/p145/run-p134r-browser.py trên branch work/p134-auto-reframe-20261121.
- Dò tương phản cạnh + sai khác frame; 9:16/1:1; WebM; giới hạn 60 giây/100 MiB. Không phải face/object AI; không upload/đụng timeline.
- Đọc kết quả PR/hosted CI trước khi merge. Không sửa PR #45. Nếu CI pass, kiểm source parity/index build/manifest trước khi xác nhận main.
- P133 trên main đã có OPFS/recovery + denoise Worker; chỉ còn proxy 720p, OffscreenCanvas use-case cụ thể và migration tài sản lớn có quota/rollback. P143 vẫn là tách mã theo từng lot và parity test.

## Consolidated continuation 2026-11-21 — P124 / P133.2 / P144.3

- P124: canvio-p124-autolayout.js + tests/p124; five layout presets/four variants, existing Website Engine adapter. Advanced breakpoint/component conversion remains partial.
- P133.2: canvio-p133-proxy.js + tests/p127/run-p133p-tests.cjs and tests/p145/run-p133-proxy-browser.py; 4K local WebM proxy, longest edge 1280 px, ≤500 MiB/180 s, new clip only. OffscreenCanvas/OPFS migration still open.
- P144.3: canvio-p144-ux.js 144.3.0; TIPS for all registered CVWS routes, existing F1/palette/tour owner; route coverage tests added.
- Consolidated branch work/canvio-p124-p133-p144-final-20261121. Wait for hosted CI before merge. P134.2 Auto Reframe is already merged to main through PR #46 (run #340 PASS).
- P143 remains staged code extraction; P122.3 MCP has no approved threat/transport/permission contract; P130 needs a real Supabase project/RLS/two-device test; P70 retains 14 manual release gates.


### P133.2 QA correction — CI #347 (2026-11-21)

- First hosted Chromium run successfully generated a 1280×720 WebM, preserved Opus audio, fully decoded the file and confirmed the original clip remained unchanged.
- It caught an actual integration race: the UI did not await the asynchronous Video Engine importFiles() promise, so the proxy download existed but the new timeline clip was not yet present when reported. Updated the module to await importFiles(), verify clip-count increase and retain the download link if timeline ingestion fails.
- CI must be rerun on the corrected commit; no proxy acceptance/merge claim until timeline import passes.


### P144.3 route-coverage correction — CI #354 (2026-11-21)

- Hosted Chromium confirmed the workspace registry contains 38 routes, not only the 25 initially covered. It identified 13 missing help topics: templates, brand, designSystem, responsive, collab, hub, platform, one, promptForge, insight, hallmark, guide and shield.
- Added page-specific guidance for all 13, using Guide-documented behavior and explicit boundaries (e.g. collab is local notes/activity, Prompt Forge is prompt handoff, Shield does not certify server headers).
- P133.2 passed all 11 Chromium checks in the same run, including actual timeline import, clip duration, audio, full decode and original preservation. P124 passed 9/9.
- Rerun required to verify all 38 CVWS routes have contextual help; no merge claim until that coverage check passes.

## Mainline handoff update — 2026-11-21 after PR #51

- Main commit e4e3647b8b49dcc931065c3f7893f68b48d9a071. PR #51 merged; candidate workflow #360 and mainline workflow #362 PASS 39/39.
- P124 Auto Layout and P133.2 4K proxy are integrated; P144.3 contextual help covers all 38 CVWS routes. P133 remaining scope: OffscreenCanvas and selected large-media OPFS migration.
- P143 PR #52 branch work/p143-source-parity-audit-20261121 adds phase-1 parity gate for 20 workflow-managed standalone source modules. Pre-browser gates passed in run #363, full same-origin browser acceptance still pending.
- Do not mark P143 full source split closed until script/style inventory, dependency/boot-order DAG and staged extraction are complete.
- P122.3 cannot be invented without MCP feature/transport/authentication/permission/threat contract. P130 remains blocked without real Supabase + RLS/two-device test. P70 fourteen manual acceptance gates remain open.

## P143 current-main branch

- Use work/p143-parity-current-main-final-20261121 (based on main 6481d83), not old branches #52/#53.
- Phase 1 source parity manifest/tests and plan are present. Prior run #363 passed all 39 steps; rerun current-main CI before merge.
- Full source split remains open; don't claim every inline script/style has been modularized.


## P134 test fix for P143 hosted validation

- Run #371 exposed a WebM metadata issue, not an exporter failure: `r_frame_rate` falsely indicated 60 fps when avg rate/format duration were missing, measuring ~4.1 seconds as 2.05 seconds.
- `tests/p145/run-p134r-browser.py` now reads packet presentation timestamps/durations and reports PTS diagnostics; fallback is the explicit canvas.captureStream(30) only when timestamps are unavailable.
- New latest-main run #373 pending on PR #54. Do not merge until success.

## P143 Phase 2 — canonical inline inventory

- Added tests/p143/build-inline-source-inventory.cjs. It runs after module integration and before full HTML audit, writes tests/p143/inline-source-inventory.json, and the JSON is included in package/evidence artifact.
- Report enumerates script tags in source order and records ids/types/src/async/defer/bytes/SHA256 plus heuristic global dependencies. It is not a semantic dependency DAG; CSS, HTML templates and dynamic imports/loaders still need separate inventory.
- Current hosted workflow must pass before treating this report as verified.

## Final verified handoff — 2026-11-21

- Main commit at handoff: c5dd364d057173a3e851e3cf4379b741e53dd8b6. PR #54 merged at 0523a8c9691fd7d10436377c53b0e489d4c0f47b.
- PR candidate run #384 and mainline run #385 both PASS 41/41. Pages #222 PASS build/deploy/report.
- P124 Auto Layout, P133.2 4K proxy and P144.3 contextual Studio help are merged (PR #51); P134.2 Auto Reframe is merged (PR #46). P134 duration QA uses packet timestamps.
- P143 parity/inventory merged (PR #54). 20 standalone modules match canonical lots; tests/p143/inline-source-inventory.json records 150 inline script tags, 0 external src, 0 duplicate IDs. Full dependency DAG, style/template inventory and project-wide extraction remain open.
- P133 OffscreenCanvas/media-to-OPFS migration and P124 advanced breakpoint/component interactions remain partial.
- P130 cannot be completed without a real Supabase backend/schema/RLS and two-device test. P122.3 MCP must not be invented without an approved threat/transport/auth/consent contract.
- P70 remains fail-closed with fourteen manual real-world gates; do not claim Stable/production-certified.


## P143 follow-up — 27 module parity candidate

- Branch work/p143-parity-27-modules-20261121 extends tests/p143/source-module-map.json from 20 to 27 pairs, adding P127 Loudness/Templates, P133 Resilience, P134 Scopes, P138 Denoise, P140 Charts and P145 SFX.
- No runtime code or script order changed. Each added pair already has an individual parity suite. Hosted CI required before merge.
- Full P143 still needs a semantic dependency/boot-order DAG, CSS/template/dynamic-loader inventory and staged extraction/rollback/offline/CSP acceptance.
